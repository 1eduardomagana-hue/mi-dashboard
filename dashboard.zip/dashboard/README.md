# Mi Dashboard — Deploy en Vercel

Dashboard personal de productividad con Kanban (Personal · Actinver · Q.Labs · Proyectos), tracker de hábitos y asistente IA.

---

## 🚀 Deploy en Vercel (5 pasos)

### 1. Instala dependencias localmente (solo para verificar)
```bash
npm install
npm run dev   # abre http://localhost:5173
```

### 2. Sube el proyecto a GitHub
1. Crea un repositorio nuevo en https://github.com/new
2. En la carpeta del proyecto ejecuta:
```bash
git init
git add .
git commit -m "Mi dashboard v1"
git remote add origin https://github.com/TU_USUARIO/mi-dashboard.git
git push -u origin main
```

### 3. Conecta con Vercel
1. Ve a https://vercel.com y entra con tu cuenta de GitHub
2. Haz clic en **"Add New Project"**
3. Importa el repositorio `mi-dashboard`
4. Vercel detecta Vite automáticamente — no cambies nada
5. Haz clic en **"Deploy"**

En ~60 segundos tendrás una URL como: `https://mi-dashboard-xxx.vercel.app`

---

## 📱 Instalar en iPhone como app (PWA)

1. Abre la URL de Vercel en **Safari** (no Chrome)
2. Toca el ícono de compartir ↑
3. Selecciona **"Añadir a pantalla de inicio"**
4. Ponle nombre y confirma

Quedará como app nativa: ícono propio, pantalla completa, sin barra de Safari.

---

## 🔑 API Key de Anthropic (para el Asistente IA)

El asistente IA usa la API de Claude. Para que funcione fuera de Claude.ai:

1. Crea una API key en https://console.anthropic.com
2. En Vercel → tu proyecto → **Settings → Environment Variables**
3. Agrega: `VITE_ANTHROPIC_KEY = sk-ant-...`
4. En `src/App.jsx`, línea del fetch, agrega el header:
   ```js
   "x-api-key": import.meta.env.VITE_ANTHROPIC_KEY,
   "anthropic-version": "2023-06-01",
   "anthropic-dangerous-direct-browser-access": "true",
   ```
5. Redeploy

> ⚠️ Nota: exponer API keys en el frontend es solo para uso personal. Para un proyecto compartido, usa un backend (Vercel Functions).

---

## 📁 Estructura del proyecto

```
mi-dashboard/
├── index.html          # Entry point + config PWA
├── vite.config.js      # Config de Vite
├── package.json
├── public/
│   ├── manifest.json   # Config PWA (ícono, nombre, tema)
│   └── icon.svg
└── src/
    ├── main.jsx        # Bootstrap de React
    └── App.jsx         # Todo el dashboard
```

---

## 💾 Persistencia de datos

Todos los datos (tareas, hábitos, notas) se guardan en **localStorage** del navegador. No se pierden al recargar. Si quieres sincronización entre iPhone y computadora, el siguiente paso sería integrar **Supabase** (gratis).
